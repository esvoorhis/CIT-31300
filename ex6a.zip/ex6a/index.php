<?php

// Display errors in production mode
ini_set('display_errors', 0); //1 is on 0 is off

require 'application/router.php';
