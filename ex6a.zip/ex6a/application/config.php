<?php
define('DEFAULT_VIEW', 'home');//set this to any page to be the default home page
define('BASE_URL', 'http://corsair.cs.iupui.edu:22351/ex6a/');
//database info
define('DB_HOST', 'localhost');
define('DB_USER', 'evoorhis');
define('DB_PASS', 'Br4nd4n10');
define('DB_NAME', 'evoorhis_db');
define('REQFIELD', '<font color="#FF0000">*</font>');
